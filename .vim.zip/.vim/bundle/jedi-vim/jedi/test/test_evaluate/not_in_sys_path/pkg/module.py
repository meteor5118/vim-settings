from not_in_sys_path import not_in_sys_path
from not_in_sys_path import not_in_sys_path_package
from not_in_sys_path.not_in_sys_path_package import module

not_in_sys_path.value
not_in_sys_path_package.value
module.value
