
#? ['raise']
raise

#? ['except', 'Exception']
except

#? []
b + continu

#? []
b + continue

#? ['continue']
b; continue

#? ['continue']
b; continu

#? []
c + brea

#? []
a + break

#? ['break']
b; break
