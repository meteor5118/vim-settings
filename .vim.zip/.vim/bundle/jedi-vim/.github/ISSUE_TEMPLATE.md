### Issue

### Steps to reproduce

### Versions

 - jedi-vim:
 - Vim / Neovim:
 - Python:

In case you are not using jedi-vim from Git master, please test it there, too.

### Output of the "JediDebugInfo" command (in a Python buffer)

### Output of the "messages" Vim command

### Output of "scriptnames" Vim command
