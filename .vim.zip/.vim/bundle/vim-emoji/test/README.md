Test cases for vim-emoji
========================

### Prerequisite

- [Vader.vim](https://github.com/junegunn/vader.vim)

### Run

```vim
:Vader*
```

